import React from 'react'

const NewUser = () => {
  return (
    <div>
      I am new user!
    </div>
  )
}

export default NewUser
