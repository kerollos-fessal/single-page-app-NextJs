import React from 'react'

const Users = () => {
  return (
    <div>
       Hello users!
    </div>
  )
}

export default Users
