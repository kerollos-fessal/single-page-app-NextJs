import Image from 'next/image';
import Link from 'next/link'; 

export default function Home() {
  return (
   <main>
      <div>Hello World!</div>
      <Link href="/users">Users</Link>
      <Link href="/users/new">New User</Link>
   </main>
  )
}
